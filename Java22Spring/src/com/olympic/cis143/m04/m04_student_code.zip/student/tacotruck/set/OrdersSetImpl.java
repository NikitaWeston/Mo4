package com.olympic.cis143.m04.student.tacotruck.set;

import com.olympic.cis143.m04.student.tacotruck.Orders;
import com.olympic.cis143.m04.student.tacotruck.TacoImpl;

public class OrdersSetImpl  implements Orders {
    @Override
    public void addOrder(TacoImpl tacoOrder) {
    }

    @Override
    public boolean hasNext() {
        return false;
    }

    @Override
    public TacoImpl closeNextOrder() {
        return null;
    }

    @Override
    public int howManyOrders() {
        return 0;
    }
}
